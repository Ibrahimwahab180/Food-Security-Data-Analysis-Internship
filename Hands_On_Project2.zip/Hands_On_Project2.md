```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

```


```python
# Load CSVs
gdp_trend = pd.read_csv('C:/data/gdp_undernourishment_trend.csv')
top_yield = pd.read_csv('C:/data/top_crop_yield.csv')
```


```python
print(gdp_trend.head())
print(top_yield.head())
```

       year   avg_gdp  avg_undernourishment
    0  2019  11262.89            4719930.00
    1  2020  11067.42            4764403.49
    2  2021  12530.81            4947037.53
    3  2022  13111.93            5112828.35
    4  2023  13686.45            5005790.33
         country     avg_yield
    0      China  1.269104e+08
    1      India  6.122670e+07
    2     Brazil  5.300999e+07
    3    Nigeria  2.788699e+07
    4  Argentina  2.513234e+07
    


```python
plt.figure(figsize=(10,6))
plt.plot(gdp_trend['year'], gdp_trend['avg_gdp'], marker='o', label='Average GDP per Capita')
plt.plot(gdp_trend['year'], gdp_trend['avg_undernourishment'], marker='s', label='Average Undernourishment (%)')

plt.title('Global Trend: GDP vs Undernourishment (2010–2023)')
plt.xlabel('year')
plt.ylabel('Values')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

```


    
![png](output_3_0.png)
    



```python
plt.figure(figsize=(10,6))
sns.barplot(
    data=top_yield,
    x='avg_yield',
    y='country',
    hue='country',
    legend=False,
    palette='crest'
)

```




    <Axes: xlabel='avg_yield', ylabel='country'>




    
![png](output_4_1.png)
    



```python

```
