```python
import pandas as pd
import os
import statsmodels.formula.api as smf
project_dir = r'C:\data'
#Loading Datasets
main = pd.read_csv(os.path.join(project_dir, 'food_security_inequality.csv'))
yield_data = pd.read_csv(os.path.join(project_dir, 'FAO_Crop_Yield_Clean.csv'), encoding='latin1')

print(" Files loaded successfully.")
print(f"Main data shape: {main.shape}")
print(f"Yield data shape: {yield_data.shape}")

```

     Files loaded successfully.
    Main data shape: (707582, 8)
    Yield data shape: (10312, 4)
    


```python
print("\n=== Data Exploration ===")

# Unique values and sample checks
print("Main data - unique countries:", main['Country'].nunique())
print("Yield data - unique countries:", yield_data['Country'].nunique())

print("Main data - unique crops:", main['Crop'].nunique())
print("Yield data - unique crops:", yield_data['Crop'].nunique())

print("\nSample countries in main:", main['Country'].unique()[:10])
print("Sample crops in main:", main['Crop'].unique()[:10])

```

    
    === Data Exploration ===
    Main data - unique countries: 139
    Yield data - unique countries: 186
    Main data - unique crops: 5
    Yield data - unique crops: 5
    
    Sample countries in main: ['ALBANIA' 'ALGERIA' 'ANGOLA' 'ARGENTINA' 'ARMENIA' 'AUSTRALIA' 'AUSTRIA'
     'AZERBAIJAN' 'BANGLADESH' 'BARBADOS']
    Sample crops in main: ['Maize (corn)' 'Rice' 'Soya beans' 'Cassava, fresh' 'Yams']
    


```python
# Standardize names for matching
main['Country'] = main['Country'].str.strip().str.title()
main['Crop'] = main['Crop'].str.strip().str.title()
yield_data['Country'] = yield_data['Country'].str.strip().str.title()
yield_data['Crop'] = yield_data['Crop'].str.strip().str.title()

# Merge on country and crop
merged = pd.merge(main, yield_data, on=['Country', 'Crop'], how='inner', suffixes=('_main', '_yield'))
print(f"\nAfter cleaning - Merged data shape: {merged.shape}")

```

    
    After cleaning - Merged data shape: (12413309, 10)
    


```python
if merged.shape[0] == 0:
    print("\n Merge returned no rows — using main dataset directly.")
    main_clean = main.dropna(subset=['Undernourishment_percent', 'GDP_per_capita', 'Yield_ton_per_ha'])
    
    print(f"Cleaned main dataset shape: {main_clean.shape}")
    
    # Regression models
    model_total = smf.ols('Undernourishment_percent ~ GDP_per_capita', data=main_clean).fit()
    model_a = smf.ols('Yield_ton_per_ha ~ GDP_per_capita', data=main_clean).fit()
    model_b = smf.ols('Undernourishment_percent ~ GDP_per_capita + Yield_ton_per_ha', data=main_clean).fit()

    # Effects
    indirect_effect = model_a.params['GDP_per_capita'] * model_b.params['Yield_ton_per_ha']
    total_effect = model_total.params['GDP_per_capita']
    proportion_mediated = indirect_effect / total_effect if total_effect != 0 else float('inf')

else:
    print("\n Merge successful — using merged dataset for analysis.")
    yield_col = 'Yield_ton_per_ha_yield'
    merged_clean = merged.dropna(subset=['Undernourishment_percent', 'GDP_per_capita', yield_col])

    # Regression models
    model_total = smf.ols('Undernourishment_percent ~ GDP_per_capita', data=merged_clean).fit()
    model_a = smf.ols(f'{yield_col} ~ GDP_per_capita', data=merged_clean).fit()
    model_b = smf.ols(f'Undernourishment_percent ~ GDP_per_capita + {yield_col}', data=merged_clean).fit()

    # Effects
    indirect_effect = model_a.params['GDP_per_capita'] * model_b.params[yield_col]
    total_effect = model_total.params['GDP_per_capita']
    proportion_mediated = indirect_effect / total_effect if total_effect != 0 else float('inf')

# Display results
print("\n=== Mediation Analysis Results ===")
print(f"Indirect effect (a*b): {indirect_effect}")
print(f"Total effect (c): {total_effect}")
print(f"Proportion mediated: {proportion_mediated:.4f}")

```

    
     Merge successful — using merged dataset for analysis.
    
    === Mediation Analysis Results ===
    Indirect effect (a*b): -12.271462685959529
    Total effect (c): -41.43044555451066
    Proportion mediated: 0.2962
    


```python
# Save dataset
if 'main_clean' in locals() and not main_clean.empty:
    main_clean.to_csv(os.path.join(project_dir, 'food_security_mediation001.csv'), index=False)
    print("\n Saved 'food_security_mediation001.csv' from main dataset.")
elif 'merged_clean' in locals() and not merged_clean.empty:
    merged_clean.to_csv(os.path.join(project_dir, 'food_security_mediation001.csv'), index=False)
    print("\n Saved 'food_security_mediation001.csv' from merged dataset.")
else:
    print("\n No valid dataset found to save.")

```

    
     Saved 'food_security_mediation001.csv' from merged dataset.
    


```python
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# Set style for better looking plots
plt.style.use('default')
sns.set_palette("husl")

# Use the main DataFrame that we know is loaded
# First, let's clean it for visualization
df_clean = main.dropna(subset=['GDP_per_capita', 'Yield_ton_per_ha', 'Undernourishment_percent'])

print(f"Using cleaned data with shape: {df_clean.shape}")
print(f"Variables available: {df_clean.columns.tolist()}")

# Create visualizations
print("\n=== Creating Visualizations ===")

# 1. Correlation Heatmap
plt.figure(figsize=(8, 6))
corr_matrix = df_clean[['GDP_per_capita', 'Yield_ton_per_ha', 'Undernourishment_percent']].corr()
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0, fmt='.3f', 
            square=True, cbar_kws={"shrink": .8})
plt.title('Correlation Matrix: GDP, Crop Yield, and Hunger', fontsize=14, pad=20)
plt.tight_layout()
plt.show()
```

    Using cleaned data with shape: (694038, 8)
    Variables available: ['Country', 'Year_x', 'Undernourishment_percent', 'GDP_per_capita', 'Crop', 'Yield_ton_per_ha', 'Year_y', 'GINI_Index']
    
    === Creating Visualizations ===
    


    
![png](output_5_1.png)
    



```python
# 2. Mediation Path Scatter Plots - CORRECTED VERSION
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# Path A: GDP → Crop Yield
scatter1 = axes[0].scatter(df_clean['GDP_per_capita'], df_clean['Yield_ton_per_ha'], 
                          alpha=0.6, s=10, c=df_clean['Undernourishment_percent'], cmap='viridis')
axes[0].set_xlabel('GDP per capita', fontsize=12)
axes[0].set_ylabel('Crop Yield (ton/ha)', fontsize=12)
axes[0].set_title('Path A: GDP → Crop Yield', fontsize=14)
fig.colorbar(scatter1, ax=axes[0], label='Undernourishment %')

# Path B: Crop Yield → Hunger
scatter2 = axes[1].scatter(df_clean['Yield_ton_per_ha'], df_clean['Undernourishment_percent'], 
               alpha=0.6, s=10, c=df_clean['GDP_per_capita'], cmap='plasma')
axes[1].set_xlabel('Crop Yield (ton/ha)', fontsize=12)
axes[1].set_ylabel('Undernourishment (%)', fontsize=12)
axes[1].set_title('Path B: Crop Yield → Hunger', fontsize=14)
fig.colorbar(scatter2, ax=axes[1], label='GDP per capita')

# Total effect: GDP → Hunger
scatter3 = axes[2].scatter(df_clean['GDP_per_capita'], df_clean['Undernourishment_percent'], 
                          alpha=0.6, s=10, c=df_clean['Yield_ton_per_ha'], cmap='magma')
axes[2].set_xlabel('GDP per capita', fontsize=12)
axes[2].set_ylabel('Undernourishment (%)', fontsize=12)
axes[2].set_title('Total Effect: GDP → Hunger', fontsize=14)
fig.colorbar(scatter3, ax=axes[2], label='Crop Yield')

plt.tight_layout()
plt.show()
```


    
![png](output_6_0.png)
    



```python
# 3. Distribution Plots
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# GDP distribution
axes[0].hist(df_clean['GDP_per_capita'], bins=50, alpha=0.7, color='skyblue', edgecolor='black')
axes[0].set_xlabel('GDP per capita', fontsize=12)
axes[0].set_ylabel('Frequency', fontsize=12)
axes[0].set_title('GDP Distribution', fontsize=14)
axes[0].grid(True, alpha=0.3)

# Crop Yield distribution
axes[1].hist(df_clean['Yield_ton_per_ha'], bins=50, alpha=0.7, color='lightgreen', edgecolor='black')
axes[1].set_xlabel('Crop Yield (ton/ha)', fontsize=12)
axes[1].set_ylabel('Frequency', fontsize=12)
axes[1].set_title('Crop Yield Distribution', fontsize=14)
axes[1].grid(True, alpha=0.3)

# Undernourishment distribution
axes[2].hist(df_clean['Undernourishment_percent'], bins=50, alpha=0.7, color='lightcoral', edgecolor='black')
axes[2].set_xlabel('Undernourishment (%)', fontsize=12)
axes[2].set_ylabel('Frequency', fontsize=12)
axes[2].set_title('Hunger Distribution', fontsize=14)
axes[2].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()
```


    
![png](output_7_0.png)
    



```python
# 4. Box Plots by Crop Type (Top 10 most common crops)
if 'Crop' in df_clean.columns:
    top_crops = df_clean['Crop'].value_counts().head(10).index
    df_top_crops = df_clean[df_clean['Crop'].isin(top_crops)]

    fig, axes = plt.subplots(1, 3, figsize=(20, 6))

    # GDP by Crop
    sns.boxplot(data=df_top_crops, x='Crop', y='GDP_per_capita', ax=axes[0])
    axes[0].set_title('GDP by Crop Type (Top 10)', fontsize=14)
    axes[0].set_xticklabels(axes[0].get_xticklabels(), rotation=45, ha='right')
    axes[0].set_ylabel('GDP per capita')

    # Yield by Crop
    sns.boxplot(data=df_top_crops, x='Crop', y='Yield_ton_per_ha', ax=axes[1])
    axes[1].set_title('Crop Yield by Crop Type (Top 10)', fontsize=14)
    axes[1].set_xticklabels(axes[1].get_xticklabels(), rotation=45, ha='right')
    axes[1].set_ylabel('Yield (ton/ha)')

    # Hunger by Crop
    sns.boxplot(data=df_top_crops, x='Crop', y='Undernourishment_percent', ax=axes[2])
    axes[2].set_title('Hunger by Crop Type (Top 10)', fontsize=14)
    axes[2].set_xticklabels(axes[2].get_xticklabels(), rotation=45, ha='right')
    axes[2].set_ylabel('Undernourishment (%)')

    plt.tight_layout()
    plt.show()
```

    C:\Users\HP\AppData\Local\Temp\ipykernel_22580\367864839.py:11: UserWarning: set_ticklabels() should only be used with a fixed number of ticks, i.e. after set_ticks() or using a FixedLocator.
      axes[0].set_xticklabels(axes[0].get_xticklabels(), rotation=45, ha='right')
    C:\Users\HP\AppData\Local\Temp\ipykernel_22580\367864839.py:17: UserWarning: set_ticklabels() should only be used with a fixed number of ticks, i.e. after set_ticks() or using a FixedLocator.
      axes[1].set_xticklabels(axes[1].get_xticklabels(), rotation=45, ha='right')
    C:\Users\HP\AppData\Local\Temp\ipykernel_22580\367864839.py:23: UserWarning: set_ticklabels() should only be used with a fixed number of ticks, i.e. after set_ticks() or using a FixedLocator.
      axes[2].set_xticklabels(axes[2].get_xticklabels(), rotation=45, ha='right')
    


    
![png](output_8_1.png)
    



```python
# 5. Time Trends (if Year data is available)
if 'Year_x' in df_clean.columns:
    # Aggregate by year
    yearly_avg = df_clean.groupby('Year_x')[['GDP_per_capita', 'Yield_ton_per_ha', 'Undernourishment_percent']].mean().reset_index()
    
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    # GDP trend
    axes[0].plot(yearly_avg['Year_x'], yearly_avg['GDP_per_capita'], marker='o', linewidth=2, markersize=4)
    axes[0].set_xlabel('Year', fontsize=12)
    axes[0].set_ylabel('Average GDP per capita', fontsize=12)
    axes[0].set_title('GDP Trend Over Time', fontsize=14)
    axes[0].grid(True, alpha=0.3)
    
    # Yield trend
    axes[1].plot(yearly_avg['Year_x'], yearly_avg['Yield_ton_per_ha'], marker='o', linewidth=2, markersize=4, color='green')
    axes[1].set_xlabel('Year', fontsize=12)
    axes[1].set_ylabel('Average Crop Yield (ton/ha)', fontsize=12)
    axes[1].set_title('Crop Yield Trend Over Time', fontsize=14)
    axes[1].grid(True, alpha=0.3)
    
    # Hunger trend
    axes[2].plot(yearly_avg['Year_x'], yearly_avg['Undernourishment_percent'], marker='o', linewidth=2, markersize=4, color='red')
    axes[2].set_xlabel('Year', fontsize=12)
    axes[2].set_ylabel('Average Undernourishment (%)', fontsize=12)
    axes[2].set_title('Hunger Trend Over Time', fontsize=14)
    axes[2].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()

```


    
![png](output_9_0.png)
    



```python
# 6. Simple scatter plots without colorbars (alternative)
print("\n=== Alternative: Simple Scatter Plots ===")
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# Simple version without colorbars
axes[0].scatter(df_clean['GDP_per_capita'], df_clean['Yield_ton_per_ha'], alpha=0.6, s=10)
axes[0].set_xlabel('GDP per capita')
axes[0].set_ylabel('Crop Yield (ton/ha)')
axes[0].set_title('Path A: GDP → Crop Yield')

axes[1].scatter(df_clean['Yield_ton_per_ha'], df_clean['Undernourishment_percent'], alpha=0.6, s=10)
axes[1].set_xlabel('Crop Yield (ton/ha)')
axes[1].set_ylabel('Undernourishment (%)')
axes[1].set_title('Path B: Crop Yield → Hunger')

axes[2].scatter(df_clean['GDP_per_capita'], df_clean['Undernourishment_percent'], alpha=0.6, s=10)
axes[2].set_xlabel('GDP per capita')
axes[2].set_ylabel('Undernourishment (%)')
axes[2].set_title('Total Effect: GDP → Hunger')

plt.tight_layout()
plt.show()
```

    
    === Alternative: Simple Scatter Plots ===
    


    
![png](output_10_1.png)
    



```python
print("\n=== Visualization Summary ===")
print(f"Total observations in visualizations: {len(df_clean):,}")
```

    
    === Visualization Summary ===
    Total observations in visualizations: 694,038
    


```python

```
