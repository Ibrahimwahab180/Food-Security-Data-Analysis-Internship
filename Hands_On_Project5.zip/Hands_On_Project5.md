```python
import pandas as pd
import os
```


```python
project_dir = r'C:\data'
```


```python
gdp_corr = pd.read_csv(os.path.join(project_dir, 'gdp_hunger_corr.csv'))
gini = pd.read_csv(os.path.join(project_dir, 'GINI_Index.csv'))
```


```python
gini = gini.rename(columns={'Country Name':'country', 'Year':'year', 'GINI index (World Bank estimate)':'GINI_Index'})
```


```python
gini = gini.rename(columns={'Country': 'country'})
```


```python
merged = gdp_corr.merge(gini, on='country', how='inner')
```


```python
merged.to_csv(os.path.join(project_dir, 'food_security_inequality.csv'), index=False)
print("Data merge successfully:", merged.shape)
```

    Data merge successfully: (1888, 4)
    


```python
print(merged.columns)

```

    Index(['country', 'gdp_hunger_corr', 'year', 'GINI_Index'], dtype='object')
    


```python
import pandas as pd
import os

# Set your folder path
project_dir = r'C:\data'

# Load the two datasets
food = pd.read_csv(os.path.join(project_dir, 'food_security_final3.csv'))
gini = pd.read_csv(os.path.join(project_dir, 'GINI_Index.csv'))
```


```python
print(food.columns)
```

    Index(['Country', 'Year', 'Undernourishment_percent', 'GDP_per_capita', 'Crop',
           'Yield_ton_per_ha'],
          dtype='object')
    


```python
print(food.shape)
print(food.head())
```

    (52412, 6)
           Country  Year  Undernourishment_percent  GDP_per_capita          Crop  \
    0  Afghanistan  2019                    1945.7      496.602504  Maize (corn)   
    1  Afghanistan  2019                    1945.7      496.602504  Maize (corn)   
    2  Afghanistan  2019                    1945.7      496.602504  Maize (corn)   
    3  Afghanistan  2019                    1945.7      496.602504          Rice   
    4  Afghanistan  2019                    1945.7      496.602504          Rice   
    
       Yield_ton_per_ha  
    0           94910.0  
    1            1945.7  
    2          184671.0  
    3          127530.0  
    4            4476.6  
    


```python
print(food.columns)
print(gini.columns)
```

    Index(['Country', 'Year', 'Undernourishment_percent', 'GDP_per_capita', 'Crop',
           'Yield_ton_per_ha'],
          dtype='object')
    Index(['Country', 'Year', 'GINI_Index'], dtype='object')
    


```python
#standardization to the 'country' column in both DataFrames
food['Country'] = food['Country'].str.strip().str.upper()
gini['Country'] = gini['Country'].str.strip().str.upper()
```


```python
merged = pd.merge(food, gini, on='Country', how='inner')
```


```python
# Successful 
print(f"Merged Data Shape: {merged.shape}")
if merged.shape[0] == 0:
    print(" WARNING: Merge still resulted in 0 rows. Check for severe data mismatch.")
```

    Merged Data Shape: (707582, 8)
    


```python
# Save the merged file
merged.to_csv(os.path.join(project_dir, 'food_security_inequality.csv'), index=False)
print(" Data merged successfully:", merged.shape)
print(merged.head())
```

     Data merged successfully: (707582, 8)
       Country  Year_x  Undernourishment_percent  GDP_per_capita          Crop  \
    0  ALBANIA    2019                    7052.9     5460.430509  Maize (corn)   
    1  ALBANIA    2019                    7052.9     5460.430509  Maize (corn)   
    2  ALBANIA    2019                    7052.9     5460.430509  Maize (corn)   
    3  ALBANIA    2019                    7052.9     5460.430509  Maize (corn)   
    4  ALBANIA    2019                    7052.9     5460.430509  Maize (corn)   
    
       Yield_ton_per_ha  Year_y  GINI_Index  
    0           55148.0    1996        27.0  
    1           55148.0    2002        31.7  
    2           55148.0    2005        30.6  
    3           55148.0    2008        30.0  
    4           55148.0    2012        29.0  
    


```python
import statsmodels.formula.api as smf
model = smf.ols('Undernourishment_percent ~ GDP_per_capita + GINI_Index + GDP_per_capita:GINI_Index', data=merged).fit()

print(model.summary())
```

                                   OLS Regression Results                               
    ====================================================================================
    Dep. Variable:     Undernourishment_percent   R-squared:                       0.006
    Model:                                  OLS   Adj. R-squared:                  0.006
    Method:                       Least Squares   F-statistic:                     1343.
    Date:                      Mon, 03 Nov 2025   Prob (F-statistic):               0.00
    Time:                              11:43:09   Log-Likelihood:            -1.2836e+07
    No. Observations:                    700950   AIC:                         2.567e+07
    Df Residuals:                        700946   BIC:                         2.567e+07
    Df Model:                                 3                                         
    Covariance Type:                  nonrobust                                         
    =============================================================================================
                                    coef    std err          t      P>|t|      [0.025      0.975]
    ---------------------------------------------------------------------------------------------
    Intercept                  9.605e+06   1.64e+05     58.721      0.000    9.28e+06    9.93e+06
    GDP_per_capita             -548.2590      9.743    -56.274      0.000    -567.354    -529.164
    GINI_Index                -1.249e+05   4054.698    -30.812      0.000   -1.33e+05   -1.17e+05
    GDP_per_capita:GINI_Index    15.9034      0.302     52.647      0.000      15.311      16.495
    ==============================================================================
    Omnibus:                   932900.319   Durbin-Watson:                   0.009
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):        161546052.853
    Skew:                           7.789   Prob(JB):                         0.00
    Kurtosis:                      75.722   Cond. No.                     5.39e+06
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The condition number is large, 5.39e+06. This might indicate that there are
    strong multicollinearity or other numerical problems.
    


```python
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(8,6))
sns.heatmap(merged[['GDP_per_capita','Undernourishment_percent','GINI_Index']].corr(), annot=True, cmap='coolwarm')
plt.title('Correlation Matrix: GDP, Hunger, and Inequality')
plt.show()
```


    
![png](output_17_0.png)
    



```python
#Regression
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd


bins = [0, 30, 45, 100]
labels = ['Low Inequality', 'Medium Inequality', 'High Inequality']
merged['GINI_Group'] = pd.cut(merged['GINI_Index'], bins=bins, labels=labels)

sns.lmplot(
    data=merged,
    x='GDP_per_capita',
    y='Undernourishment_percent',
    hue='GINI_Group',
    palette='viridis',
    height=6,
    aspect=1.3,
    scatter_kws={'alpha':0.6, 's':50}  # make points slightly transparent
)

plt.title('Figure 2: GDP vs Hunger Reduction by Inequality Level', fontsize=13, pad=15)
plt.xlabel('GDP per Capita (Current US$)', fontsize=11)
plt.ylabel('Undernourishment (% of Population)', fontsize=11)
plt.legend(title='Inequality Level', loc='upper right', fontsize=9, title_fontsize=10)
plt.show()

```


    
![png](output_18_0.png)
    



```python

```
