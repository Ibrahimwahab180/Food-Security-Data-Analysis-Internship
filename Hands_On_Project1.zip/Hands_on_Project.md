```python
import pandas as pd
import os
project_dir = r'C:\Users\HP\Desktop\Data Analysis Hands-on Project'

# Loading datasets
undernourish = pd.read_csv(os.path.join(project_dir, 'FAO_Undernourishment_Clean.csv'), encoding='latin-1')
gdp = pd.read_csv(os.path.join(project_dir, 'WorldBank_GDP_Clean.csv'), encoding='latin-1')
yield_data = pd.read_csv(os.path.join(project_dir, 'FAO_Crop_Yield_Clean.csv'), encoding='latin-1')
```


```python
print("Undernourishment Data:")
print(undernourish.head())
```

    Undernourishment Data:
           Country  Year  Undernourishment_percent
    0  Afghanistan  2019                    1945.7
    1  Afghanistan  2019                  184671.0
    2  Afghanistan  2020                    1934.4
    3  Afghanistan  2020                  271776.0
    4  Afghanistan  2021                    1900.4
    


```python
print("Undernourishment Data:")
print(undernourish.head())
```

    Undernourishment Data:
           Country  Year  Undernourishment_percent
    0  Afghanistan  2019                    1945.7
    1  Afghanistan  2019                  184671.0
    2  Afghanistan  2020                    1934.4
    3  Afghanistan  2020                  271776.0
    4  Afghanistan  2021                    1900.4
    


```python
print("\nCrop Yield Data:")
print(yield_data.head())
```

    
    Crop Yield Data:
           Country          Crop  Year  Yield_ton_per_ha
    0  Afghanistan  Maize (corn)  2018           72433.0
    1  Afghanistan  Maize (corn)  2018            1472.7
    2  Afghanistan  Maize (corn)  2018          106670.0
    3  Afghanistan  Maize (corn)  2019           94910.0
    4  Afghanistan  Maize (corn)  2019            1945.7
    


```python
merged = undernourish.merge(gdp, on=['Country', 'Year'], how='inner')
merged = merged.merge(yield_data, on=['Country', 'Year'], how='inner')
```


```python
merged.to_csv(os.path.join(project_dir, 'Food_Security_Final.csv'), index=False)

print("\n Merged dataset saved successfully!")
print("Merged dataset shape:", merged.shape)
```

    
     Merged dataset saved successfully!
    Merged dataset shape: (52412, 6)
    


```python
print(merged.columns.tolist())

```

    ['Country', 'Year', 'Undernourishment_percent', 'GDP_per_capita', 'Crop', 'Yield_ton_per_ha']
    


```python
import seaborn as sns
import matplotlib.pyplot as plt

# Correlation matrix 
print(merged[['GDP_per_capita', 'Undernourishment_percent', 'Yield_ton_per_ha']].corr())

# Scatter plot - GDP vs Undernourishment
sns.scatterplot(data=merged, x='GDP_per_capita', y='Undernourishment_percent')
plt.title('Relationship between GDP per Capita and Undernourishment')
plt.show()

# Scatter plot - Yield_ton_per_ha vs Undernourishment
sns.scatterplot(data=merged, x='Yield_ton_per_ha', y='Undernourishment_percent')
plt.title('Relationship between Yield_ton_per_ha and Undernourishment')
plt.show()
```

                              GDP_per_capita  Undernourishment_percent  \
    GDP_per_capita                  1.000000                 -0.006318   
    Undernourishment_percent       -0.006318                  1.000000   
    Yield_ton_per_ha               -0.022463                  0.225641   
    
                              Yield_ton_per_ha  
    GDP_per_capita                   -0.022463  
    Undernourishment_percent          0.225641  
    Yield_ton_per_ha                  1.000000  
    


    
![png](output_7_1.png)
    



    
![png](output_7_2.png)
    



```python

```
