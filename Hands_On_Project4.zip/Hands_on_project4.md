```python
import pandas as pd

df = pd.read_csv(r'C:\data\Food_Security_Final.csv')
print(df.head())

```

           Country  Year  Undernourishment_percent  GDP_per_capita          Crop  \
    0  Afghanistan  2019                    1945.7      496.602504  Maize (corn)   
    1  Afghanistan  2019                    1945.7      496.602504  Maize (corn)   
    2  Afghanistan  2019                    1945.7      496.602504  Maize (corn)   
    3  Afghanistan  2019                    1945.7      496.602504          Rice   
    4  Afghanistan  2019                    1945.7      496.602504          Rice   
    
       Yield_ton_per_ha  
    0           94910.0  
    1            1945.7  
    2          184671.0  
    3          127530.0  
    4            4476.6  
    


```python
import matplotlib.pyplot as plt
import pandas as pd

gdp_growth = pd.read_csv(r'C:\data\gdp_growth1.csv')
hunger_change = pd.read_csv(r'C:\data\hunger_change1.csv')

plt.figure(figsize=(15,8))
plt.plot(gdp_growth['year'], gdp_growth['gdp_growth_percent'], label='GDP Growth (%)', marker='o')
plt.plot(hunger_change['year'], hunger_change['hunger_change'], label='Change in Undernourishment (%)', marker='s')
plt.title('GDP Growth vs Hunger Change Over Time')
plt.xlabel('Year')
plt.ylabel('Percentage Change')
plt.legend()
plt.show()

```


    
![png](output_1_0.png)
    



```python
import seaborn as sns

merged = pd.merge(gdp_growth, hunger_change, on=['country', 'year'])
sns.scatterplot(data=merged, x='gdp_growth_percent', y='hunger_change')
plt.title('Relationship Between GDP Growth and Hunger Change')
plt.xlabel('GDP Growth (%)')
plt.ylabel('Change in Undernourishment (%)')
plt.show()

```


    
![png](output_2_0.png)
    



```python

```
