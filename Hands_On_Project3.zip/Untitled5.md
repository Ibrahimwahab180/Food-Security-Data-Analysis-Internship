```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
project_dir = r'C:\data'

hunger_reduction = pd.read_csv(os.path.join(project_dir, 'top5_hunger_reduction.csv'))
gdp_growth = pd.read_csv(os.path.join(project_dir, 'gdp_growth.csv'))
corr_data = pd.read_csv(os.path.join(project_dir, 'gdp_hunger_corr.csv'))
yield_data = pd.read_csv(os.path.join(project_dir, 'avg_crop_yield.csv'))

print(hunger_reduction.head())
print(gdp_growth.head())
```

                  country  reduction_percent
    0  Russian Federation        29781252.00
    1           Australia        26719268.56
    2              Canada        13015100.00
    3             Ukraine        11454060.00
    4              France        10423820.00
           country   gdp_growth
    0        Qatar  37017.95791
    1    Singapore  28888.99020
    2      Ireland  23424.31895
    3   Luxembourg  22269.16630
    4  Switzerland  16509.87177
    


```python
plt.figure(figsize=(8,5))
sns.barplot(
    data=hunger_reduction,
    x='reduction_percent',
    y='country',
    hue='country',
    palette='crest',
    legend=False
)
plt.title('Top 5 Countries with Greatest Reduction in Undernourishment (2010–2023)')
plt.xlabel('Reduction in Undernourishment (%)')
plt.ylabel('Country')
plt.tight_layout()
plt.show()

```


    
![png](output_1_0.png)
    



```python
import numpy as np

food = pd.read_csv(r'C:\data\Food_Security_Final.csv')

countries = ['Nigeria', 'India', 'Brazil']
subset = food[food['Country'].isin(countries)]

plt.figure(figsize=(8,6))
sns.scatterplot(
    data=subset,
    x='GDP_per_capita',
    y='Undernourishment_percent',
    hue='Country',
    style='Country',
    s=80
)
plt.title('GDP vs Undernourishment (Selected Countries)')
plt.xlabel('GDP per Capita (USD)')
plt.ylabel('Undernourishment (%)')
plt.grid(True)
plt.tight_layout()
plt.show()

```


    
![png](output_2_0.png)
    



```python
plt.figure(figsize=(8,5))
sns.barplot(data=yield_data, x='avg_yield', y='crop', hue='crop', legend=False, palette='viridis')
plt.title('Average Crop Yield by Crop Type (tonnes per ha)')
plt.xlabel('Average Yield (tonnes/ha)')
plt.ylabel('Crop')
plt.tight_layout()
plt.show()

```


    
![png](output_3_0.png)
    



```python

```
